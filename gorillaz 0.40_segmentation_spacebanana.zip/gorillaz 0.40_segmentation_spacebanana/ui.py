import tkinter as tk

def create_labeled_entry(window, label_text):
    tk.Label(window, text=label_text).pack()
    entry = tk.Entry(window)
    entry.pack()
    return entry
