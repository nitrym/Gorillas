import tkinter as tk
from game import Game
from constants import CANVAS_WIDTH, CANVAS_HEIGHT

# Fenster und Canvas vorbereiten
window = tk.Tk()
window.title("Banana Joe 0.40")
canvas = tk.Canvas(window, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg="skyblue")
canvas.pack()

# Spiel starten
game = Game(window, canvas)
window.mainloop()
