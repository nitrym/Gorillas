import tkinter as tk  # <-- Dieser Import ist notwendig!
from constants import CANVAS_WIDTH
from buildings import create_buildings
from gorillas import place_gorilla
from banana import throw
from ui import create_labeled_entry

class Game:
    def __init__(self, window, canvas):
        self.canvas = canvas
        self.window = window

        # Gebäude erstellen
        self.buildings, self.building_hits = create_buildings(canvas, CANVAS_WIDTH)

        # Gorillas platzieren
        self.gorilla1 = place_gorilla(canvas, self.buildings[1], "orange")
        self.gorilla2 = place_gorilla(canvas, self.buildings[-2], "purple")

        # UI-Elemente
        self.angle_entry = create_labeled_entry(window, "Winkel (°):")
        self.speed_entry = create_labeled_entry(window, "Stärke:")
        self.throw_button = tk.Button(window, text="Werfen (Gorilla 1)", command=self.throw_banana)
        self.throw_button.pack()

    def throw_banana(self):
        try:
            angle = float(self.angle_entry.get())
            speed = float(self.speed_entry.get())
        except ValueError:
            print("Ungültige Eingabe")
            return

        throw(self.canvas, angle, speed, self.gorilla1, self.gorilla2, self.buildings, self.building_hits)
