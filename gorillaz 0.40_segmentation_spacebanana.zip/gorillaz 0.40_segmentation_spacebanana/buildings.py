import random
from constants import CANVAS_HEIGHT, BUILDING_WIDTH

def create_buildings(canvas, canvas_width):
    buildings = []
    building_hits = {}
    for x in range(0, canvas_width, BUILDING_WIDTH):
        height = random.randint(100, 250)
        top = CANVAS_HEIGHT - height
        canvas.create_rectangle(x, top, x + BUILDING_WIDTH, CANVAS_HEIGHT, fill="gray")
        buildings.append((x, top, x + BUILDING_WIDTH, CANVAS_HEIGHT))
        building_hits[x] = []
    return buildings, building_hits
