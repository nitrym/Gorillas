def place_gorilla(canvas, building, color):
    x1, y1, x2, _ = building
    gx = (x1 + x2) / 2 - 10
    gy = y1 - 20
    return canvas.create_oval(gx, gy, gx + 20, gy + 20, fill=color)
