# Konfigurierbare Spielkonstanten

CANVAS_WIDTH = 1000
CANVAS_HEIGHT = 500

BUILDING_WIDTH = 50
GRAVITY = 0.5
