import tkinter as tk
from constants import CANVAS_WIDTH
from buildings import create_buildings
from gorillas import place_gorilla
from banana import throw

def create_labeled_entry(parent, label_text):
    frame = tk.Frame(parent)
    label = tk.Label(frame, text=label_text)
    label.pack(side="left")
    entry = tk.Entry(frame)
    entry.pack(side="left")
    frame.pack(side="left", padx=10)  # Nebeneinander mit Abstand
    frame.entry = entry
    return frame


class Game:
    def __init__(self, window, canvas):
        self.window = window
        self.canvas = canvas
        self.current_player = 1
        self.score = {1: 0, 2: 0}

        # --- Eingabe-Bereich oben (nebeneinander) ---
        self.top_frame = tk.Frame(window)
        self.top_frame.pack(side="top", fill="x", pady=5)

        self.player1_frame = create_labeled_entry(self.top_frame, "Spieler 1 Name:")
        self.player1_name_entry = self.player1_frame.entry

        self.player2_frame = create_labeled_entry(self.top_frame, "Spieler 2 Name:")
        self.player2_name_entry = self.player2_frame.entry

        self.target_score_frame = create_labeled_entry(self.top_frame, "Zielpunkte (1–20):")
        self.target_score_entry = self.target_score_frame.entry

        self.start_button = tk.Button(self.top_frame, text="Spiel starten", command=self.start_game)
        self.start_button.pack(side="left", padx=10)

        # --- Steuerung (erst nach Start sichtbar) ---
        self.controls_frame = tk.Frame(window)

        self.angle_frame = create_labeled_entry(self.controls_frame, "Winkel (°):")
        self.angle_entry = self.angle_frame.entry

        self.speed_frame = create_labeled_entry(self.controls_frame, "Stärke:")
        self.speed_entry = self.speed_frame.entry

        self.throw_button = tk.Button(self.controls_frame, text="Werfen", command=self.throw_banana)

        # --- Neustart-Button unten ---
        self.restart_button = tk.Button(window, text="Neustart", command=self.reset_game)
        self.restart_button.pack(pady=10)

    def start_game(self):
        # Werte einlesen
        self.player1_name = self.player1_name_entry.get() or "Spieler 1"
        self.player2_name = self.player2_name_entry.get() or "Spieler 2"

        try:
            self.target_score = int(self.target_score_entry.get())
            if not 1 <= self.target_score <= 20:
                raise ValueError
        except ValueError:
            self.show_canvas_message("Bitte gültige Zielpunkte (1–20) eingeben.")
            return

        # Eingabe-Felder oben entfernen
        self.player1_frame.pack_forget()
        self.player2_frame.pack_forget()
        self.target_score_frame.pack_forget()
        self.start_button.pack_forget()

        # Score initialisieren und anzeigen
        self.score = {1: 0, 2: 0}
        self.current_player = 1

        # Spielfeld zeichnen
        self.canvas.delete("all")
        self.buildings, self.building_hits = create_buildings(self.canvas, CANVAS_WIDTH)
        self.gorilla1 = place_gorilla(self.canvas, self.buildings[1], "orange")
        self.gorilla2 = place_gorilla(self.canvas, self.buildings[-2], "purple")

        # Score-Text auf Canvas erstellen
        self.score_text_id = self.canvas.create_text(
            CANVAS_WIDTH // 2, 20,
            text="", fill="black", font=("Arial", 14, "bold")
        )
        self.update_score_label()

        # Steuerung anzeigen (Frames packen)
        self.controls_frame.pack()
        self.throw_button.pack()
        self.throw_button.config(text=f"Werfen ({self.get_current_player_name()})", state="normal")

    def throw_banana(self):
        try:
            angle = float(self.angle_entry.get())
            speed = float(self.speed_entry.get()) * 0.25
        except ValueError:
            self.show_canvas_message("Ungültige Eingabe für Winkel oder Stärke.")
            return

        # Winkel für Player 2 spiegeln
        if self.current_player == 2:
            angle = 180 - angle

        # throw gibt True zurück, wenn Gegner getroffen wurde, sonst False
        hit_player = throw(
            self.canvas,
            angle,
            speed,
            self.gorilla1 if self.current_player == 1 else self.gorilla2,
            self.gorilla2 if self.current_player == 1 else self.gorilla1,
            self.buildings,
            self.building_hits
        )

        if hit_player:
            self.score[self.current_player] += 1
            self.update_score_label()

            if self.score[self.current_player] >= self.target_score:
                winner = self.get_current_player_name()
                self.show_canvas_message(f"{winner} gewinnt mit {self.target_score} Punkten!")
                self.throw_button.config(state="disabled")
                return
        else:
            self.show_canvas_message("Kein Treffer!")

        # Spieler wechseln
        self.current_player = 2 if self.current_player == 1 else 1
        self.throw_button.config(text=f"Werfen ({self.get_current_player_name()})")

    def get_current_player_name(self):
        return self.player1_name if self.current_player == 1 else self.player2_name

    def update_score_label(self):
        score_text = f"{self.player1_name}: {self.score[1]}  |  {self.player2_name}: {self.score[2]}"
        self.canvas.itemconfig(self.score_text_id, text=score_text)

    def show_canvas_message(self, message):
        print(message)

    def reset_game(self):
        self.canvas.delete("all")
        self.score = {1: 0, 2: 0}
        self.throw_button.config(state="normal")

        # Eingabe-Felder wieder sichtbar machen
        self.player1_frame.pack(side="left", padx=10)
        self.player2_frame.pack(side="left", padx=10)
        self.target_score_frame.pack(side="left", padx=10)
        self.start_button.pack(side="left", padx=10)

        # Steuerung verbergen
        self.controls_frame.pack_forget()
        