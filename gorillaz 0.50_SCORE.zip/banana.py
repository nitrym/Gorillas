import math
from constants import GRAVITY, CANVAS_WIDTH, CANVAS_HEIGHT
from sound import play_sound

def draw_banana(canvas, x, y):
    return canvas.create_arc(x, y, x + 40, y + 15, start=0, extent=180, fill="yellow", outline="orange", width=2)

def create_explosion(canvas, x, y, buildings, building_hits):
    play_sound("boom.wav")
    r = 10
    offsets = [(0,0), (10,0), (-10,0), (0,10), (0,-10), (7,7), (-7,7), (7,-7), (-7,-7)]

    for dx, dy in offsets:
        ex, ey = x + dx, y + dy
        ex1, ey1, ex2, ey2 = ex - r, ey - r, ex + r, ey + r

        for x1b, y1b, x2b, y2b in buildings:
            if ex1 < x2b and ex2 > x1b and ey1 < y2b and ey2 > y1b:
                canvas.create_oval(max(ex1, x1b), max(ey1, y1b), min(ex2, x2b), min(ey2, y2b), fill="black", outline="black")
                building_hits[int(x1b)].append((ey1, ey2))

def is_destroyed(col_x, y, building_hits):
    for y1, y2 in building_hits[col_x]:
        if y1 <= y <= y2:
            return True
    return False

def throw(canvas, angle_deg, speed, gorilla1, gorilla2, buildings, building_hits):
    play_sound("yeet.wav")

    angle_rad = math.radians(angle_deg)
    x, y = canvas.coords(gorilla1)[0] + 10, canvas.coords(gorilla1)[1]
    vx = math.cos(angle_rad) * speed
    vy = -math.sin(angle_rad) * speed

    banana = draw_banana(canvas, x, y)

    def animate():
        nonlocal x, y, vx, vy
        vy += GRAVITY
        x += vx
        y += vy
        canvas.move(banana, vx, vy)

        bx1, by1, bx2, by2 = canvas.coords(banana)
        cx = (bx1 + bx2) / 2
        cy = (by1 + by2) / 2

        gx1, gy1, gx2, gy2 = canvas.coords(gorilla2)
        if gx1 < cx < gx2 and gy1 < cy < gy2:
            play_sound("hit.wav")
            canvas.delete(banana)
            canvas.create_text(CANVAS_WIDTH // 2, 50, text="Treffer! Gorilla 2!", font=("Arial", 16), fill="red")
            return

        for x1b, y1b, x2b, y2b in buildings:
            if x1b < cx < x2b and y1b < cy < y2b:
                if is_destroyed(int(x1b), cy, building_hits):
                    break
                else:
                    canvas.delete(banana)
                    create_explosion(canvas, cx, cy, buildings, building_hits)
                    return

        #if x > CANVAS_WIDTH or y > CANVAS_HEIGHT or x < 0 or y < 0:
         #   canvas.delete(banana)
          #  return

        canvas.after(30, animate)

    animate()
